document.getElementById("contact-form").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent form from submitting

    // Get form data
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const message = document.getElementById("message").value;

    // Simple validation (you can expand this)
    if (name && email && message) {
        alert(`شكراً لك، ${name}! تم إرسال رسالتك.`);
        // Clear the form
        this.reset();
    } else {
        alert("يرجى ملء جميع الحقول.");
    }
});
// Placeholder for future JavaScript code
console.log("Welcome to the Telemedicine Platform!");

